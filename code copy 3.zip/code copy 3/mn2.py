# EstebanEscapes
from settings import *
import pygame as pg
import pygame
from os import path
import os
from sp2 import *
import math
import time

dtCounter = 0
jumps = 0
speed = 0
speedC = 0

class Game:

    def __init__(self):
        # init game window etc
        self.running = True  # set the while loop to true
        pg.font.init()  # allows for text to be printed onscreen
        pg.mixer.init()  # init sound
        pg.init()  # initilazie pygame
        self.screen = pg.display.set_mode((WIDTH, HEIGHT))  # set the display size
        pg.display.set_caption(TITLE)  # set the name of the game
        self.clock = pg.time.Clock()  # set fps
        self.countt = 1
        self.deadScreenB = False #for showing the 'You Died' screen
        self.timer = 45000
        while 1 == 1:
            try:
                self.load_data(self.mlcounter)  # runs a function that reads the map file
                break
            except AttributeError:
                self.load_data(1)
                break

    def load_data(self, levelcount):
        game_folder = os.path.dirname(__file__)  # sets a path to the same folder as the code
        self.map_data = []  # creates an empty list to add the contents of a text file
        with open(path.join(game_folder, 'levels/level' + str(levelcount) + '.txt'),
                  'rt') as f:  # opens path to map file as a readable
            for line in f:  # adds everything in the map file to the list self.map_data
                self.map_data.append(line)

    def new(self):
        # new game -  creates various sprite groups and instances of classes such as platforms
        # some values that need to be defined at the beginning of the game
        while 1 == 1:
            try:
                self.load_data(self.mlcounter)  # runs a function that reads the map file
                break
            except AttributeError:
                self.load_data(1)
                break
        self.all_sprites = pg.sprite.Group()
        self.platforms = pg.sprite.Group()
        self.spikes = pg.sprite.Group()
        self.trophy = pg.sprite.Group()
        self.endgametile1 = pg.sprite.Group()
        self.endgametile2 = pg.sprite.Group()
        self.endgametile3 = pg.sprite.Group()
        self.skulls = pg.sprite.Group()
        self.enemy_list = pg.sprite.Group()
        self.tiles = pg.sprite.Group()
        # self.skully = Skull(self)
        self.Esteban = Player(self)
        self.all_sprites.add(self.Esteban)
        self.momentum = 0
        self.sspinCount = 0
        self.coins = pg.sprite.Group()
        self.coin11 = pg.sprite.Group()
        self.coin12 = pg.sprite.Group()
        self.coin13 = pg.sprite.Group()
        self.coin1 = False
        self.coin2 = False
        self.coin3 = False
        self.trophy_status = False
        self.locker = False
        self.locktime = 0
        while 1 == 1:
            try:
                self.mlcounter = self.mlcounter
                break
            except AttributeError:
                self.mlcounter = 1
                break


        # read text file give every element an x, y based on col and row in file
        for row, tiles in enumerate(self.map_data):
            for col, tile in enumerate(tiles):
                if tile == 'u':
                    np = Platform(col, row)
                    np.image = pg.image.load(os.path.join(game_folder, 'images/tiles/level'+ str(self.mlcounter) +'/tl.png')).convert()
                    self.all_sprites.add(np)
                    PLATFORM_LIST.append(np)
                    self.platforms.add(np)
                    self.tiles.add(np)
                if tile == 'i':
                    np = Platform(col, row)
                    np.image = pg.image.load(os.path.join(game_folder, 'images/tiles/level'+ str(self.mlcounter) +'/mt.png')).convert()
                    self.all_sprites.add(np)
                    PLATFORM_LIST.append(np)
                    self.platforms.add(np)
                    self.tiles.add(np)
                if tile == 'o':
                    np = Platform(col, row)
                    np.image = pg.image.load(os.path.join(game_folder, 'images/tiles/level'+ str(self.mlcounter) +'/tr.png')).convert()
                    self.all_sprites.add(np)
                    PLATFORM_LIST.append(np)
                    self.platforms.add(np)
                    self.tiles.add(np)
                if tile == 'j':
                    np = Platform(col, row)
                    np.image = pg.image.load(os.path.join(game_folder, 'images/tiles/level'+ str(self.mlcounter) +'/ml.png')).convert()
                    self.all_sprites.add(np)
                    PLATFORM_LIST.append(np)
                    self.platforms.add(np)
                    self.tiles.add(np)
                if tile == 'k':
                    np = Platform(col, row)
                    np.image = pg.image.load(os.path.join(game_folder, 'images/tiles/level'+ str(self.mlcounter) +'/m.png')).convert()
                    self.all_sprites.add(np)
                    PLATFORM_LIST.append(np)
                    self.platforms.add(np)
                    self.tiles.add(np)
                if tile == 'l':
                    np = Platform(col, row)
                    np.image = pg.image.load(os.path.join(game_folder, 'images/tiles/level'+ str(self.mlcounter) +'/mr.png')).convert()
                    self.all_sprites.add(np)
                    PLATFORM_LIST.append(np)
                    self.platforms.add(np)
                    self.tiles.add(np)
                if tile == 'v':
                    np = Platform(col, row)
                    np.image = pg.image.load(os.path.join(game_folder, 'images/tiles/level'+ str(self.mlcounter) +'/v.png')).convert()
                    self.all_sprites.add(np)
                    PLATFORM_LIST.append(np)
                    self.platforms.add(np)
                    self.tiles.add(np)
                if tile == 'b':
                    np = Platform(col, row)
                    np.image = pg.image.load(os.path.join(game_folder, 'images/tiles/level'+ str(self.mlcounter) +'/b.png')).convert()
                    self.all_sprites.add(np)
                    PLATFORM_LIST.append(np)
                    self.platforms.add(np)
                    self.tiles.add(np)
                if tile == 'n':
                    np = Platform(col, row)
                    np.image = pg.image.load(os.path.join(game_folder, 'images/tiles/level'+ str(self.mlcounter) +'/n.png')).convert()
                    self.all_sprites.add(np)
                    PLATFORM_LIST.append(np)
                    self.platforms.add(np)
                    self.tiles.add(np)
                if tile == 'f':
                    np = Platform(col, row)
                    np.image = pg.image.load(os.path.join(game_folder, 'images/tiles/level' + str(self.mlcounter) +'/f.png')).convert()
                    self.all_sprites.add(np)
                    PLATFORM_LIST.append(np)
                    self.platforms.add(np)
                    self.tiles.add(np)
                if tile == "s":
                    skll = Skull(col, row)
                    self.all_sprites.add(skll)
                    self.skulls.add(skll)
                    self.tiles.add(skll)
                if tile == "S":
                    skll = Spike(col, row)
                    self.all_sprites.add(skll)
                    self.spikes.add(skll)
                    self.tiles.add(skll)
                if tile == "z":
                    end = endtile(col, row)
                    end.image = pg.image.load(os.path.join(game_folder, 'images/tiles/level'+str(self.mlcounter)+'/z.png')).convert_alpha()
                    self.all_sprites.add(end)
                    if self.mlcounter == 1:
                        self.endgametile1.add(end)
                    elif self.mlcounter == 2:
                        self.endgametile2.add(end)
                    elif self.mlcounter == 3:
                        self.endgametile3.add(end)
                if tile == "x":
                    end = endtile(col, row)
                    end.image = pg.image.load(os.path.join(game_folder, 'images/tiles/level'+str(self.mlcounter)+'/x.png')).convert_alpha()
                    end.image.set_colorkey(BLACK)
                    self.all_sprites.add(end)
                    if self.mlcounter == 1:
                        self.endgametile1.add(end)
                    elif self.mlcounter == 2:
                        self.endgametile2.add(end)
                    elif self.mlcounter == 3:
                        self.endgametile3.add(end)
                if tile == "t":
                    np = trophy(col, row)
                    np.image = pg.image.load(os.path.join(game_folder, 'images/tiles/level'+ str(self.mlcounter)+ '/f.png')).convert()
                    self.trophy.add(np)
                    for event in pg.event.get():
                        if event.type == pg.KEYDOWN:
                            if event.key == pg.K_f and pg.sprite.spritecollide(self.Esteban, self.trophy, False):
                                self.trophy_status = True
                                np.kill()
                                self.trophy.empty()
                if tile == "7":
                    np = trophy(col, row)
                    np.image = pg.image.load(os.path.join(game_folder, 'images/level1/coin-1.png.png')).convert()
                    self.coins.add(np)
                    self.coin11.add(np)
                if tile == "8":
                    np = trophy(col, row)
                    np.image = pg.image.load(os.path.join(game_folder, 'images/level1/coin-1.png.png')).convert()
                    self.coins.add(np)
                    self.coin12.add(np)
                if tile == "9":
                    np = trophy(col, row)
                    np.image = pg.image.load(os.path.join(game_folder, 'images/level1/coin-1.png.png')).convert()
                    self.coins.add(np)
                    self.coin13.add(np)


                # each character in the text file relates to a instance of a class and this is basically where the map is created
                # from the map

        self.clist = []
        for img in range(1,7):
            self.clist.append(pg.image.load(os.path.join(game_folder, 'images/level1/coin-' + str(img)) + '.png.png').convert_alpha())

        self.hud = pg.image.load(os.path.join(game_folder, 'images/level1/hud.png')).convert_alpha()

        self.tr = []

        for img in range(1, 23):
            self.tr.append(pg.image.load(os.path.join(game_folder, 'images/Level1/' + 'Level 1 Treasure clone-' + str(img) + '.png' + '.png')).convert_alpha())


        self.bg = pg.image.load(os.path.join(game_folder, 'images/tiles/level' + str(self.mlcounter) + '/background.png')) #background changes depending on level

        ##################################     HEALTH BAR  ###############################################
        self.healthbar = []
        for img in range(1,7):
            healthBarIMG = pg.image.load(os.path.join(game_folder, 'images/Esteban/h' + str(img) + '.png')).convert_alpha()
            healthBarIMG = pg.transform.scale(healthBarIMG, (106, 32))
            self.healthbar.append(healthBarIMG)

        self.dcoin = pg.image.load(os.path.join(game_folder, 'images/level1/dcoin.png')).convert_alpha()
        self.bcoin = pg.image.load(os.path.join(game_folder, 'images/level1/coin-1.png.png')).convert_alpha()
        self.btr = pg.image.load(os.path.join(game_folder, 'images/level1/Level 1 Treasure clone-1.png.png')).convert_alpha()
        self.dtr = pg.image.load(os.path.join(game_folder, 'images/level1/Level 1 Treasure clone-2.png (1).png')).convert_alpha()

        self.espinP = []
        for pic in range(8):
            self.espin = pg.image.load('images/Esteban/' + str(pic) + '.png')
            self.espinP.append(self.espin)

        self.sspinP = []
        for pic in range(5):
            self.sspin = pg.image.load('images/traps/' + str(pic) + '.png')
            self.sspinP.append(self.sspin)

        self.spspinP = []
        for pic in range(25):
            if pic <= 9:
                self.spspin = pg.image.load('images/traps/Spike/spike0' + str(pic) + '.png')
            else:
                self.spspin = pg.image.load('images/traps/Spike/spike' + str(pic) + '.png')
            self.spspinP.append(self.spspin)

        self.deadScreen = pg.image.load('images/DiedScreen.png')


        self.run()

    def run(self):
        # game loop - calls all the functions in the order they run in in the game loop
        self.playing = True
        self.espinCount = 0 #Esteban spin counter
        self.sspinCount = 0 #skull spin counter
        self.spspinCount = 0 #spike spin counter
        self.tspinCount = 0 #trophy spin counter
        self.cspinCount = 0 #coin spin counter
        spinForward = True #for spinning forward and backward for spikes

        self.startTime = 0
        while self.playing:
            # self.momentum += 0.005 code that is wip for acceleration
            self.dt = self.clock.tick(FPS)
            if self.trophy_status == True:
                self.timer -= self.dt
            self.events()
            self.update()
            self.draw()

            for skl in self.skulls:
                if (-32 < skl.rect.x < 800):
                    skl.image = self.sspinP[round(self.sspinCount)]
                    self.sspinCount += 0.0075
                    if round(self.sspinCount) == 5:
                        self.sspinCount = 0

            for spike in self.spikes:
                if (-32 < spike.rect.x < 800):
                    spike.image = self.spspinP[round(self.spspinCount)]
                    if spinForward == True:
                        self.spspinCount += 0.5
                        if round(self.spspinCount) == 24:
                            spinForward = False
                    else:
                        self.spspinCount -= 0.5
                        if round(self.spspinCount) == 0:
                            spinForward = True

            for tr in self.trophy:
                tr.image = self.tr[round(self.tspinCount)]
                self.tspinCount += 0.2
                if round(self.tspinCount) == 22:
                    self.tspinCount = 0

            for coin in self.coins:
                coin.image = self.clist[round(self.cspinCount)]
                self.cspinCount += 0.02
                if round(self.cspinCount) == 6:
                    self.cspinCount = 0

            if self.Esteban.change_x == 0:
                self.Esteban.image = self.espinP[0]
            else:
                self.Esteban.image = self.espinP[round(self.espinCount)]
                self.espinCount += 0.5
                if round(self.espinCount) == 8:
                    self.espinCount = 0

                # last line in loop (AFTER DRAWING EVERYTHING) -- Update the full display Surface to the screen
            pg.display.flip()

    def events(self):
        # game loop - events
        global jumps
        global speed
        global speedC

        for event in pg.event.get():
            # check for closing window
            if event.type == pg.QUIT:
                self.endgame()
                quit()
            if event.type == pg.KEYDOWN and self.running == True:  # events when a button is pushed down - currently only controls character movement
                if event.key == pg.K_LEFT or event.key == pg.K_a:
                    self.Esteban.go_left()
                if event.key == pg.K_RIGHT or event.key == pg.K_d:
                    self.Esteban.go_right()
                    # self.Esteban.change_x += self.momentum code that is wip for acceleration
                if event.key == pg.K_UP or event.key == pg.K_SPACE or event.key == pg.K_w:
                    self.Esteban.jump()
                    jumps += 1
                if event.key == pg.K_f and pg.sprite.spritecollide(self.Esteban, self.trophy, False):
                    self.trophy_status = True

            if event.type == pg.KEYUP:  # when the button is no longer being pressed
                if (event.key == pg.K_LEFT or event.key == pg.K_a) and self.Esteban.change_x < 0:
                    self.Esteban.stop()
                    speed += self.Esteban.change_x
                    speedC += 1
                if (event.key == pg.K_RIGHT or event.key == pg.K_d) and self.Esteban.change_x > 0:
                    self.Esteban.stop()
                    speed += self.Esteban.change_x
                    speedC += 1


        if self.Esteban.health <= 0 or self.timer <= 0:  # checks players health if it is equal to or less than 0
            if self.timer <= 0:
                self.timer = 0
            elif self.trophy_status == True:
                self.timer += self.dt

            print("Oh, dios mio Esteban died")
            self.running = False
            self.Esteban.change_x = 0
            self.startTime += self.dt
            if self.startTime < 3000:
                print(self.startTime)
                self.deadScreenB = True
            else:
                self.startTime = 0
                self.deadScreenB = False
                self.running = True
                self.endgame()

        if self.Esteban.health >= 60:
            self.Esteban.health = 60

        if pg.sprite.spritecollide(self.Esteban, self.coin11, False):
            self.coin1 = True
        if pg.sprite.spritecollide(self.Esteban, self.coin12, False):
            self.coin2 = True
        if pg.sprite.spritecollide(self.Esteban, self.coin13, False):
            self.coin3 = True

    def update(self):
        # game loop - update
        self.all_sprites.update()  # updates all sprites in the all sprites group
        self.enemy_list.update()

        for tile in self.tiles:
            if tile.rect.x < -32:
                tile.kill()

        global speed
        global speedC

        if self.Esteban.rect.right >= WIDTH / 5:  # Locks player to the left section of the sreen
            self.Esteban.rect.right = WIDTH / 5
        if self.Esteban.rect.right <= WIDTH / 7:
            self.Esteban.rect.right = WIDTH / 7

        if self.Esteban.change_x > 0:
            # moves the platforms to the left depending the players velocity gives the illusion of movemtent
            for plat in self.platforms:
                plat.rect.x += -1.2 * (self.Esteban.change_x)
            for skl in self.skulls:
                skl.rect.x += -1.2 * (self.Esteban.change_x)
            for end in self.endgametile1:
                end.rect.x += -1.2 * (self.Esteban.change_x)
            for end in self.endgametile2:
                end.rect.x += -1.2 * (self.Esteban.change_x)
            for end in self.endgametile3:
                end.rect.x += -1.2 * (self.Esteban.change_x)
            for end in self.trophy:
                end.rect.x += -1.2 * (self.Esteban.change_x)
            for end in self.coins:
                end.rect.x += -1.2 * (self.Esteban.change_x)
            for end in self.spikes:
                end.rect.x += -1.2 * (self.Esteban.change_x)
            speed += self.Esteban.change_x
            speedC += 1
        ends1 = pg.sprite.spritecollide(self.Esteban, self.endgametile1 ,False)  # checks for collisions with the last tiles in the level and if it collides closes the game
        if ends1 and self.trophy_status == True:
            self.countt = 2
            self.transition_screen(True)
            self.load_data(self.mlcounter)
            self.new()

        ends2 = pg.sprite.spritecollide(self.Esteban, self.endgametile2,
                                        False)  # checks for collisions with the last tiles in the level and if it collides closes the game
        if ends2 and self.trophy_status == True:
            self.countt = 3
            self.transition_screen(False)
            self.load_data(self.mlcounter)
            self.new()

        ends3 = pg.sprite.spritecollide(self.Esteban, self.endgametile3,
                                        False)  # checks for collisions with the last tiles in the level and if it collides closes the game
        if ends3 and self.trophy_status == True:
            self.countt = 4
            self.transition_screen(False)
            self.load_data(self.mlcounter)
            self.new()

    def draw(self):
        # render game
        self.screen.fill(BLACK)
        self.screen.blit(self.bg, (0, 0))  # background
        self.enemy_list.draw(self.screen)  # draws sprite group on screen
        self.all_sprites.draw(self.screen)  # draws sprite group on screen
        self.platforms.draw(self.screen)  # draws sprite group on screen
        self.screen.blit(self.hud, (0, 2))
        self.myfont = pg.font.SysFont('Comic Sans MS', 20)  # defines a font that allows for printing on screens

        if 60 >= self.Esteban.health > 50:
            self.screen.blit(self.healthbar[0], (WIDTH/12, 9))
        elif 50 >= self.Esteban.health > 40:
            self.screen.blit(self.healthbar[1], (WIDTH/12, 9))
        elif 40 >= self.Esteban.health > 30:
            self.screen.blit(self.healthbar[2], (WIDTH/12, 9))
        elif 30 >= self.Esteban.health > 20:
            self.screen.blit(self.healthbar[3], (WIDTH/12, 9))
        elif 20 >= self.Esteban.health > 10:
            self.screen.blit(self.healthbar[4], (WIDTH/12, 9))
        elif 10 >= self.Esteban.health > 0:
            self.screen.blit(self.healthbar[5], (WIDTH/12, 9))

        self.textsurface2 = self.myfont.render('Time: ' + (str(self.timer/1000)), False,
                                               (WHITE))  # prints velocity health on screen
        self.screen.blit(self.textsurface2, (WIDTH - 150, HEIGHT - 600))  # prints velocity health on screen

        if self.trophy_status == False:
            self.trophy.draw(self.screen)
            self.screen.blit(self.dtr, (350, 9))
        else:
            self.screen.blit(self.btr, (350, 9))
        if self.coin1 == False:
            self.coin11.draw(self.screen)
            self.screen.blit(self.dcoin, (375, 9))
        else:
            self.screen.blit(self.bcoin, (375, 9))
        if self.coin2 == False:
            self.coin12.draw(self.screen)
            self.screen.blit(self.dcoin, (400, 9))
        else:
            self.screen.blit(self.bcoin, (400, 9))
        if self.coin3 == False:
            self.coin13.draw(self.screen)
            self.screen.blit(self.dcoin, (425, 9))
        else:
            self.screen.blit(self.bcoin, (425, 9))

        if self.startTime < 3000 and self.deadScreenB == True:
            self.screen.blit(self.deadScreen, (0, 0))



    def show_start_screen(self):
        # start screen
        menuIMG = pg.image.load('menus/MainMenuBackground.png')
        menuIMG = pg.transform.scale(menuIMG, (800, 608))
        clearBlack75 = pg.image.load('menus/transpBlack75.png')
        clearBlack75 = pg.transform.scale(clearBlack75, (800, 200))
        clearBlack75Stats = pg.transform.scale(clearBlack75, (200, 200))

        self.dty = self.clock.tick(FPS)

        # pg.mixer.music.load('menus/Ancient, Desert, Thoughtful Song - Non Copyright, Royalty Free.ogg')
        # pg.mixer.music.set_volume(1)
        # pg.mixer.music.play(-1)

        fontGlobal = 'Arial'

        spinP = []

        for pic in range(32):
            if pic <= 9:
                spin = pg.image.load('pyramidSpinIMG/frame_0' + str(pic) + '_delay-0.06s.png')
            else:
                spin = pg.image.load('pyramidSpinIMG/frame_' + str(pic) + '_delay-0.06s.png')
            spin = pg.transform.scale(spin, (210, 160))
            spinP.append(spin)

        class button():
            def __init__(self, x, y, font, font_size, text='', boldness=False):
                self.x = x
                self.y = y
                self.text = text
                self.font = font
                self.font_size = font_size
                self.boldness = boldness
                self.screen = pg.display.set_mode((WIDTH, HEIGHT))
                pg.font.init()

            def draw(self, win, outline=None):
                font = pg.font.SysFont(self.font, self.font_size, bold=self.boldness)
                text = font.render(self.text, 1, (255, 255, 255))
                if outline:
                    pg.draw.rect(win, outline, (self.x, self.y, text.get_width(), text.get_height()), 0)

                if self.text != '':
                    font = pg.font.SysFont(self.font, self.font_size, bold=self.boldness)
                    text = font.render(self.text, 1, (255, 255, 255))
                    self.screen.blit(text, (self.x, self.y))

            def isOver(self, pos):
                font = pg.font.SysFont(self.font, self.font_size, bold=self.boldness)
                text = font.render(self.text, 1, (255, 255, 255))
                if pos[0] > self.x and pos[0] < self.x + text.get_width():
                    if pos[1] > self.y and pos[1] < self.y + text.get_height():
                        return True

                return False

        def redrawWindow():
            startButton.draw(self.screen)
            storeButton.draw(self.screen)
            optionsButton.draw(self.screen)
            objectivesButton.draw(self.screen)
            creditsButton.draw(self.screen)
            statsButton.draw(self.screen)

        run = True
        startButton = button(250, 470, fontGlobal, 18, 'Start Game')
        storeButton = button(250, 535, fontGlobal, 18, 'Store')
        optionsButton = button(435, 470, fontGlobal, 18, 'Options')
        objectivesButton = button(435, 535, fontGlobal, 18, 'Objectives')
        creditsButton = button(620, 470, fontGlobal, 18, 'Credits')
        statsButton = button(620, 535, fontGlobal, 18, 'Stats')

        spinCount = 0
        self.statsClick = False
        while run:
            self.screen.blit(menuIMG, (0, 0))
            self.screen.blit(clearBlack75, (0, 445))
            self.screen.blit(spinP[spinCount], (0, 445))
            spinCount += 1
            if spinCount == 32:
                spinCount = 0
            redrawWindow()

            for event in pg.event.get():
                pos = pg.mouse.get_pos()

                if event.type == pg.QUIT:
                    run = False
                    pg.quit()
                    quit()

                if event.type == pg.MOUSEBUTTONDOWN:
                    if startButton.isOver(pos):
                        self.timer = 45000
                        while self.running:# runs the game loop
                            # self.new()
                            self.transition_screen(True)
                        run = False
                        # self.timer = 45000
                        # self.mlcounter = 1
                    if storeButton.isOver(pos):
                        print('clicked the store button')
                    if optionsButton.isOver(pos):
                        print('clicked the options button')
                    if objectivesButton.isOver(pos):
                        print('clicked the objectives button')
                    if creditsButton.isOver(pos):
                        print('clicked the credits button')
                    if statsButton.isOver(pos):
                        self.statsTimer = 0
                        self.statsClick = True
                        self.statsTimer += self.dty
                        print(self.statsTimer)
                        if self.statsTimer < 30000:
                            self.screen.blit(clearBlack75Stats, (300, 200))
                        else:
                            self.statsTimer = 0

                        print('Jumps:', jumps)
                        print('speed:', speed)
                        print('speedC:', speedC)
                        print('avgSpeed:', speed/(speedC+0.0000001))
                        print('clicked the stats button')

                if event.type == pg.MOUSEMOTION:
                    if startButton.isOver(pos):
                        startButton.boldness = True
                    elif storeButton.isOver(pos):
                        storeButton.boldness = True
                    elif optionsButton.isOver(pos):
                        optionsButton.boldness = True
                    elif objectivesButton.isOver(pos):
                        objectivesButton.boldness = True
                    elif creditsButton.isOver(pos):
                        creditsButton.boldness = True
                    elif statsButton.isOver(pos):
                        statsButton.boldness = True
                    else:
                        startButton.boldness = False
                        storeButton.boldness = False
                        optionsButton.boldness = False
                        objectivesButton.boldness = False
                        creditsButton.boldness = False
                        statsButton.boldness = False

            if self.statsClick == True:
                self.statsTimer += self.dty
                print(self.dty)
                if self.statsTimer < 5000:
                    self.screen.blit(clearBlack75Stats, (300, 200))
                else:
                    self.statsTimer = 0
                    self.statsClick = False

            pg.display.update()

    def transition_screen(self, guideON):
        win = pygame.display.set_mode((WIDTH, HEIGHT))
        win.fill((255, 255, 255))

        self.myfont = pg.font.SysFont('Comic Sans MS', 20)  # defines a font that allows for printing on screens

        backIMG = pygame.image.load('menus/WorldMap.png')
        backIMG = pygame.transform.scale(backIMG, (800, 600))
        TheX = pygame.image.load('menus/TheX.png')
        TheX = pygame.transform.scale(TheX, (32, 32))
        TheXB = pygame.image.load('menus/TheXB.png')
        TheXB = pygame.transform.scale(TheXB, (32, 32))
        padlockB = pygame.image.load('menus/padlockIMGB.png')
        padlockB = pygame.transform.scale(padlockB, (26, 26))
        padlockG = pygame.image.load('menus/padlockIMGG.png')
        padlockG = pygame.transform.scale(padlockG, (26, 26))
        backButtonR = pygame.image.load('menus/backButtonR.png')
        backButtonR = pygame.transform.scale(backButtonR, (32, 18))
        backButtonO = pygame.image.load('menus/backButtonO.png')
        backButtonO = pygame.transform.scale(backButtonO, (32, 18))
        worldMessage = pg.image.load('images/WorldMessage.png').convert_alpha()
        worldMessage = pygame.transform.scale(worldMessage, (400, 200))
        continueButtonT = pg.image.load('images/Doodle-Button-Continue.png').convert_alpha()
        continueButtonW = pg.image.load('images/Doodle-Button-Continue (1).png').convert_alpha()
        self.startTime = 0
        self.locker = False

        fontGlobal = 'Arial'

        spinP = []

        class button():
            def __init__(self, x, y, font, font_size, text='', boldness=False):
                self.x = x
                self.y = y
                self.text = text
                self.font = font
                self.font_size = font_size
                self.boldness = boldness

            def draw(self, win, outline=None):
                font = pygame.font.SysFont(self.font, self.font_size, bold=self.boldness)
                text = font.render(self.text, 1, (255, 255, 255))
                if outline:
                    pygame.draw.rect(win, outline, (self.x, self.y, text.get_width(), text.get_height()), 0)

                if self.text != '':
                    font = pygame.font.SysFont(self.font, self.font_size, bold=self.boldness)
                    text = font.render(self.text, 1, (255, 255, 255))
                    win.blit(text, (self.x, self.y))

            def isOver(self, pos):
                font = pygame.font.SysFont(self.font, self.font_size, bold=self.boldness)
                text = font.render(self.text, 1, (255, 255, 255))
                if pos[0] > self.x and pos[0] < self.x + text.get_width():
                    if pos[1] > self.y and pos[1] < self.y + text.get_height():
                        return True

                return False

        class XButton():
            def __init__(self, x, y, image, image2, image_width, image_height):
                self.x = x
                self.y = y
                self.image = image
                self.image2 = image2
                self.image_width = image_width
                self.image_height = image_height

            def isOver(self, pos):
                if pos[0] > self.x and pos[0] < self.x + self.image_width:
                    if pos[1] > self.y and pos[1] < self.y + self.image_height:
                        return True

                return False

            def draw(self, win):
                pos = pygame.mouse.get_pos()
                if self.isOver(pos):
                    win.blit(self.image2, (self.x, self.y))
                else:
                    win.blit(self.image, (self.x, self.y))

        mexicoButton = XButton(120, 210, TheXB, TheX, 32, 32)
        greeceButton = XButton(410, 160, padlockB, padlockG, 26, 26)
        egyptButton = XButton(430, 195, padlockB, padlockG, 26, 26)
        backButtonIcon = XButton(10, 10, backButtonO, backButtonR, 32, 18)
        continueButton = XButton(300, 325, continueButtonT, continueButtonW, 200, 59)
        self.dtx = self.clock.tick(FPS)
        self.mexClick = False

        def redrawWindow():
            mexicoButton.draw(win)
            greeceButton.draw(win)
            egyptButton.draw(win)
            backButtonIcon.draw(win)

            if self.locker == True:
                if dtCounter > 0 and self.mexClick:
                    self.startTime += self.dt
                    print(self.startTime)
                    if self.startTime < 3000:
                        self.lock = self.myfont.render('LOCKED', False, (RED))  # prints players health on screen
                        self.screen.blit(self.lock, (WIDTH / 2, HEIGHT / 2))
                    else:
                        self.locker = False
                        self.startTime = 0
                else:
                    self.startTime += self.dtx
                    print(self.startTime)
                    if self.startTime < 30000:
                        self.lock = self.myfont.render('LOCKED', False, (RED))  # prints players health on screen
                        self.screen.blit(self.lock, (WIDTH / 2, HEIGHT / 2))
                    else:
                        self.locker = False
                        self.startTime = 0

        global dtCounter
        self.runm = True
        while self.runm:
            win.blit(backIMG, (0, 0))
            self.lvl1 = self.myfont.render('1', False, (BLACK))
            self.screen.blit(self.lvl1, (130, 190))
            self.lvl2 = self.myfont.render('2', False, (BLACK))
            self.screen.blit(self.lvl2, (418, 135))
            self.lvl3 = self.myfont.render('3', False, (BLACK))
            self.screen.blit(self.lvl3, (437, 215))
            redrawWindow()
            if guideON:
                win.blit(worldMessage, (200, 200))
                continueButton.draw(win)
            pygame.display.update()

            for event in pygame.event.get():
                pos = pygame.mouse.get_pos()

                if event.type == pygame.QUIT:
                    self.runm = False
                    pygame.quit()
                    quit()
                self.level1 = True
                self.level2 = False
                self.level3 = False
                if self.countt >= 1:
                    self.level1 = True
                if self.countt >= 2:
                    self.level2 = True
                if self.countt >= 3:
                    self.level3 = True
                if self.countt >= 4:
                    pygame.quit()
                    quit()

                if self.level1 == True:
                    mexicoButton = XButton(120, 210, TheXB, TheX, 32, 32)
                    self.mexClick = True
                else:
                    mexicoButton = XButton(120, 210, padlockB, padlockG, 32, 32)
                if self.level2 == True:
                    greeceButton = XButton(410, 160, TheXB, TheX, 32, 32)
                else:
                    greeceButton = XButton(410, 160, padlockB, padlockG, 32, 32)
                if self.level3 == True:
                    egyptButton = XButton(430, 195, TheXB, TheX, 26, 26)
                else:
                    egyptButton = XButton(430, 195, padlockB, padlockG, 26, 26)




                if event.type == pygame.MOUSEBUTTONDOWN:

                    if continueButton.isOver(pos):
                        guideON = False
                    if mexicoButton.isOver(pos):
                        self.timer = 45000
                        self.mlcounter = 1
                        self.new()
                    if greeceButton.isOver(pos) and self.level2 == True:# Changed to False for testing only (Change to True later)
                        self.timer = 10000
                        self.mlcounter = 2
                        self.new()
                    elif greeceButton.isOver(pos) and self.level2 == False:
                        self.locker = True

                    if egyptButton.isOver(pos) and self.level3 == True:
                        self.mlcounter = 3
                        self.new()
                    elif egyptButton.isOver(pos) and self.level3 == False:
                        self.locker = True
                        print(dtCounter)
                    if backButtonIcon.isOver(pos):
                        dtCounter = 1
                        self.show_start_screen()

    def endgame(self):
        if self.playing:
            self.playing = False


g = Game()  # creates of an instance of the game class
pg.mixer.music.load('menus/Ancient, Desert, Thoughtful Song - Non Copyright, Royalty Free.ogg')
pg.mixer.music.set_volume(1)
pg.mixer.music.play(-1)
g.show_start_screen()  # shows start screen
